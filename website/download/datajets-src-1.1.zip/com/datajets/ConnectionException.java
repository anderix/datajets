/*
DataJets, an object-relational framework.<br>
Copyright (c) 2003-2005,  Anderix

Please view the full copyright notice on http://www.datajets.com/license.php.

Contact Anderix on http://www.anderix.com or dave@anderix.com.
*/
package com.datajets;

/**
Thrown when a DataJet cannot connect to the specified database.
If the database is online and available, check your connection properties in 
<code>setConnection</code>.

@author David M. Anderson
*/
public class ConnectionException extends java.lang.Exception {

	/**
	Class constructor specifying the message to add.
	
	@param msg the message to add
	*/
	public ConnectionException(String msg) {
		super("There was a problem connecting to the database. Check your driver and connection string. " + msg);
	}
}
