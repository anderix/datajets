/*
DataJets, an object-relational framework.<br>
Copyright (c) 2003-2005,  Anderix

Please view the full copyright notice on http://www.datajets.com/license.php.

Contact Anderix on http://www.anderix.com or dave@anderix.com.
*/
package com.datajets;

import java.sql.Connection;

/**
Used to manage java.sql.Connection objects required by DataJets. The
DataJet class can create and manage its own Connection objects, or you can
manage them yourself using a ConnectionGenerator. Creating a class that
implements ConnectionGenerator allows you to do the following:

<ul>
<li>Share the same connection information between several DatJets</li>
<li>Use a Connection object obtained from a connection pool.</li>
</ul>

@author David M. Anderson
*/
public interface ConnectionGenerator {

	/**
	Establishes the connection to be used by a DataJet. 
	A typical implementation contains:
	<code><pre>
	String driver = [insert driver];
	String url = [insert connection url];
	Class.forName(driver);
	Connection con = DriverManager.getConnection(url);
	return con;
	</pre></code>	
	
	@throws ConnectionException if there is a problem creating a connection to the database
	*/
	public Connection createConnection() throws ConnectionException;

	/**
	Frees resources after DataJet is finished using the Connection. 
	A typical implementation contains:
	<code><pre>
    try {
        con.close();
    } catch ( Exception ex ) {
    	//no action required - connection is already closed.
    }
	</pre></code>	
	*/
	public void closeConnection(Connection con);
}